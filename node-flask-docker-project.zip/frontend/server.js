const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const axios = require('axios');
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('views'));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'form.html'));
});

app.post('/submit', (req, res) => {
  const data = req.body;
  axios.post('http://backend:5000/submit', data)
    .then(response => res.send(response.data))
    .catch(error => res.send('Error sending data to backend: ' + error));
});

app.listen(3000, () => {
  console.log('Frontend running on http://localhost:3000');
});